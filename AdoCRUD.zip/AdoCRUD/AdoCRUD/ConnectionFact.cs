﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoCRUD
{
    public class ConnectionFact
    {
        public static SqlConnection GetConnection()
        {
            return new SqlConnection(Properties.Settings.Default.D3Connection);
        }
    }
}
