﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace AdoCRUD
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();


            
        }

       
        private static List<Paises> GetPaises()
        {
            var connection = ConnectionFact.GetConnection();
            var command = connection.CreateCommand();
            command.CommandText = "SELECT * FROM Paises";

            connection.Open();

            var dataReader = command.ExecuteReader();
            List<Paises> paises = new List<Paises>();
            while (dataReader.Read())
            {
                Paises p = new Paises();
                p.IdPais = (int)dataReader["IdPais"];
                p.CodigoPais = (string)dataReader["CodigoPais"];
                p.NombrePais = (string)dataReader["NombrePais"];
                paises.Add(p);
            }

            dataReader.Close();
            connection.Close();

            return paises;
        }

        private static List<Sexos> GetSexos()
        {
            var connection = ConnectionFact.GetConnection();
            var command = connection.CreateCommand();
            command.CommandText = "SELECT * FROM Sexos";

            connection.Open();

            var dataReader = command.ExecuteReader();
            List<Sexos> sexos = new List<Sexos>();
            while (dataReader.Read())
            {
                Sexos s = new Sexos();
                s.IdSexo = (int)dataReader["IdSexo"];
                s.Sexo = (string)dataReader["Sexo"];
                sexos.Add(s);
            }

            dataReader.Close();
            connection.Close();

            return sexos;
        }

        private void CargarPersonas(DataGridView Dgv)
        {
            var connection = ConnectionFact.GetConnection();
            SqlDataAdapter DataAdapter = new SqlDataAdapter("SELECT * FROM Persona", connection);
            DataTable DataTable = new DataTable();
            DataAdapter.Fill(DataTable);
            Dgv.DataSource = DataTable;
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text) | string.IsNullOrWhiteSpace(txtTelefono.Text) | string.IsNullOrWhiteSpace(txtCorreo.Text))
            {
                MessageBox.Show("No se admiten campos vacios, favor de rellenar todos los campos");
            }
            else
            {
                try
                {
                    var connection = ConnectionFact.GetConnection();
                    var command = connection.CreateCommand();
                    command.CommandText = @"INSERT INTO [dbo].[Persona]
                    ([Nombres],[Foto],[Fechanacimiento],[IdPais],[Sexo],[Telefono],[CorreoElectronico])
                     VALUES(@Nombres, @Foto, @Fechanacimiento, @IdPais, @Sexo, @Telefono,@CorreoElectronico)";

                    command.Parameters.AddWithValue("@Nombres", txtName.Text);
                    command.Parameters.AddWithValue("@Foto", PbPersonas.ImageLocation.ToString());
                    command.Parameters.AddWithValue("@Fechanacimiento", dtpFecha.Value);
                    command.Parameters.AddWithValue("@IdPais", CbPais.SelectedValue.ToString());
                    command.Parameters.AddWithValue("@Sexo", CbSexo.SelectedValue.ToString());
                    command.Parameters.AddWithValue("@Telefono", txtTelefono.Text);
                    command.Parameters.AddWithValue("@CorreoElectronico", txtCorreo.Text);

                    connection.Open();

                    int affectedRows = command.ExecuteNonQuery();

                    connection.Close();

                    Console.WriteLine("Inserted");
                    Limpiar();
                }
                catch (Exception Error)
                {
                    MessageBox.Show("Se ha presentado un error. " + Error.Message);
                }
                CargarPersonas(dgvPersona);
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text) | string.IsNullOrWhiteSpace(txtTelefono.Text) | string.IsNullOrWhiteSpace(txtCorreo.Text) | (string.IsNullOrWhiteSpace(txtID.Text)))
            {
                MessageBox.Show("No se admiten campos vacios, favor de rellenar todos los campos");
            }
            else
            {
                try
                {
                    var connection = ConnectionFact.GetConnection();
                    var command = connection.CreateCommand();
                    command.CommandText = @"UPDATE [dbo].[Persona] SET
                    [Nombres] = @Nombres,
                    [Foto] = @Foto,
                    [Fechanacimiento] = @Fechanacimiento,
                    [IdPais] = @IdPais,
                    [Sexo] = @Sexo,
                    [Telefono] = @Telefono,
                    [CorreoElectronico] = @CorreoElectronico
                     WHERE [IdPersona] = @IdPersona";

                    command.Parameters.AddWithValue("@IdPersona", txtID.Text);
                    command.Parameters.AddWithValue("@Nombres", txtName.Text);
                    command.Parameters.AddWithValue("@Foto", PbPersonas.ImageLocation.ToString());
                    command.Parameters.AddWithValue("@Fechanacimiento", dtpFecha.Value);
                    command.Parameters.AddWithValue("@IdPais", CbPais.SelectedValue.ToString());
                    command.Parameters.AddWithValue("@Sexo", CbSexo.SelectedValue.ToString());
                    command.Parameters.AddWithValue("@Telefono", txtTelefono.Text);
                    command.Parameters.AddWithValue("@CorreoElectronico", txtCorreo.Text);

                    connection.Open();

                    int affectedRows = command.ExecuteNonQuery();

                    connection.Close();

                    Console.WriteLine("Updated");
                    Limpiar();
                }
                catch (Exception Error)
                {
                    MessageBox.Show("Se ha presentado un error. " + Error.Message);
                }
                CargarPersonas(dgvPersona);
            }
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtID.Text))
            {
                MessageBox.Show("Favor de rellenar el campo del Id para poder proceder");
            }
            else
            {
                try
                {
                    var connection = ConnectionFact.GetConnection();
                    string Query = "DELETE FROM Persona WHERE IdPersona = @IdPersona";

                    connection.Open();
                    SqlCommand Command = new SqlCommand(Query, connection);

                    Command.Parameters.AddWithValue("@IdPersona", txtID.Text);

                    Command.ExecuteNonQuery();
                    MessageBox.Show("Usuario eliminado");
                    connection.Close();
                    Limpiar();
                    CargarPersonas(dgvPersona);
                }
                catch (Exception Error)
                {
                    MessageBox.Show("Se ha presentado un error. " + Error.Message);
                }
            }
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            var connection = ConnectionFact.GetConnection();
            SqlCommand Command = new SqlCommand("SELECT * FROM Persona", connection);
            SqlDataAdapter DataAdapter = new SqlDataAdapter();
            DataAdapter.SelectCommand = Command;
            DataTable DataTable = new DataTable();
            DataAdapter.Fill(DataTable);
            dgvPersona.DataSource = DataTable;

            DataTable Dt = new DataTable();

            CbSexo.DataSource = GetSexos();
            CbSexo.DisplayMember = "Sexo"; 
            CbSexo.ValueMember = "IdSexo";

            CbPais.DataSource = GetPaises();
            CbPais.DisplayMember = "NombrePais";
            CbPais.ValueMember = "IdPais";
        }

        private void btnPhoto_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            string PhotoPersona = openFileDialog1.FileName;

            PbPersonas.ImageLocation = PhotoPersona;
        }

        private void CbPais_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        internal class Paises
        {
            public int IdPais { get; set; }

            public string CodigoPais { get; set; }

            public string NombrePais { get; set; }
        }

        internal class Sexos
        {
            public int IdSexo { get; set; }

            public string Sexo { get; set; }

        }

        internal class Persona
        {
            public string Nombres { get; set; }

            public string Foto { get; set; }

            public DateTime Fechanacimiento { get; set; }

            public int IdPais { get; set; }

            public int Sexo { get; set; }

            public string Telefono { get; set; }

            public int CorreoElectronico { get; set; }
        }

        private void Limpiar()
        {
            foreach (var i in this.Controls)
            {
                if (i is TextBox)
                    ((TextBox)i).Text = "";
            }

            foreach (var i in this.Controls)
            {
                if (i is MaskedTextBox)
                    ((MaskedTextBox)i).Text = "";
            }

            foreach (var i in this.Controls)
            {
                if (i is ComboBox)
                    ((ComboBox)i).SelectedIndex = 0;
            }
        }

        private void dgvPersona_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtID.Text = dgvPersona.CurrentRow.Cells[0].Value.ToString();
                txtName.Text = dgvPersona.CurrentRow.Cells[1].Value.ToString();
                PbPersonas.ImageLocation = dgvPersona.CurrentRow.Cells[2].Value.ToString();
                dtpFecha.Value = DateTime.Parse(dgvPersona.CurrentRow.Cells[3].Value.ToString());
                CbPais.DisplayMember = dgvPersona.CurrentRow.Cells[4].Value.ToString();
                CbSexo.DisplayMember = dgvPersona.CurrentRow.Cells[5].Value.ToString();
                txtTelefono.Text = dgvPersona.CurrentRow.Cells[6].Value.ToString();
                txtCorreo.Text = dgvPersona.CurrentRow.Cells[7].Value.ToString();
            }
            catch (Exception Error)
            {
                MessageBox.Show("Se ha producido el error: " + Error.Message);
            }
        }

        private void dgvPersona_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
